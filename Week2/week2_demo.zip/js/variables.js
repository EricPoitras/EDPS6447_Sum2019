/* 

Example of multi-line comments syntax in JS:
https://www.w3schools.com/js/js_comments.asp

Single line comments can be added via "//"

*/

// Debug your code by printing information in the console. Open the console in your browser's developer tool. For additional options, see https://www.w3schools.com/js/js_output.asp

console.log("Hello World!");
