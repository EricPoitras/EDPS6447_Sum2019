/* Listen for locate icon click event */
input_ico_locate.addEventListener("click", ico_locate_click);

/* Listen for location button click event */
input_btn_location.addEventListener("click", btn_location_click);